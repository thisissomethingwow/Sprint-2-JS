let html
fetch('./data.json')
    .then(response => response.json())
    .then(data => {

    data.forEach(people => {
      console.log('Hobby:', people.Hobby)
    });
    function getName(people){
      return `Name: ${people.Name}`;
    }
    
    function getAge(people){
      return `Age: ${people.Age}`;
    }

    function getHobby(people){
      return `Hobby: ${people.Hobby}`;
    }
    const peopleDiv = document.createElement(`div`);
    data.forEach(people => {
      peopleDiv.innerHTML += `<h3><p>${getName(people)}<br> ${getAge(people)}<br> ${getHobby(people)}</p></h3><hr>`;
    });
    document.body.appendChild(peopleDiv)
       console.log("JSON data", data);
    })

  .catch(error => {
    console.error(error);
  });
